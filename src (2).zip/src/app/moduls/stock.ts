export interface Stock {
    id:number,
    id_farmacia: number,
    id_producto: number,
    cantidad_unidad: number,
    precio_unitario: number
}