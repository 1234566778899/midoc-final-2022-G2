export interface ProductoStock {
    nombre: string,
    registro_sanitario: string,
    presentacion: string,
    tipo: string,
    esRecetado: boolean,
    descripcion: string,
    cantidad_unidad: number,
    precio_unitario: number
}