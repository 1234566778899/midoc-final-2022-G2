export interface DetalleCliente {
    id:number
    nombre: string,
    apellido: string,
    dni: string,
    cantidad: number,
    monto: number
}