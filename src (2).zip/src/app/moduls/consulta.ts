export interface Consulta {
    id:number,
    nombre: string,
    correo: string,
    descripcion: string
}