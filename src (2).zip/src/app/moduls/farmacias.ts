export interface Farmacia {
    id: number;
    nombre: string;
    RUC: string;
    Distrito: string;
    Provincia: string;
    Departamento: string;
    ApellidoTitular:string;
    NombreTitular:string;
    Telefono: string;
    correo:string;
    password: string;
}
