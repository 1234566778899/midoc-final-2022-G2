import { StocksService } from './../../services/stocks/stocks.service';
import { Stock } from './../../moduls/stock';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductosService } from './../../services/productos/productos.service';
import { Producto } from './../../moduls/producto';
import { startWith, map } from 'rxjs/operators';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-add-edit-products',
  templateUrl: './add-edit-products.component.html',
  styleUrls: ['./add-edit-products.component.css']
})
export class AddEditProductsComponent implements OnInit {
  myControl = new FormControl('');
  options: Producto[] = [];
  filteredOptions!: Observable<Producto[]>;
  myForm!: FormGroup;
  idFarmacia!: number;
  idProducto!: number;
  constructor(private productoService: ProductosService, private formBuilder: FormBuilder,
    private activated: ActivatedRoute, private stockService: StocksService, private router: Router) { }

  ngOnInit(): void {
    this.idFarmacia = this.activated.snapshot.params['id'];
    this.getProductos();
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''), map(value => this._filter(value || '')),
    );

    this.reactiveForm();
  }

  reactiveForm() {
    this.myForm = this.formBuilder.group(
      {
        producto: [''],
        precio: ['', [Validators.required]],
        cantidad: ['', [Validators.required]]
      }
    )
  }

  agregarStock() {

    if (this.idProducto == undefined) {
      alert('Debe completar los campos');
    } else {
      let element: Stock = {
        id: 0,
        id_farmacia: this.idFarmacia,
        id_producto: this.idProducto,
        cantidad_unidad: this.myForm.get('cantidad')?.value,
        precio_unitario: this.myForm.get('precio')?.value
      }
      this.stockService.addStock(element).subscribe({
        next: (data: Stock) => {
          this.router.navigate(['/inventario/' + this.idFarmacia]);
        },
        error: (e) => {
          console.log(e);
        }
      })
    }

  }
  private _filter(value: string): Producto[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.nombre.toLowerCase().includes(filterValue) ||
      option.presentacion.toLowerCase().includes(filterValue));
  }
  getProductos() {
    this.productoService.getProductos().subscribe(
      (data: Producto[]) => {
        this.options = data;
      }
    )
  }
  conseguirProducto(data: Producto) {

    let registro = document.querySelector('#registro') as HTMLInputElement;
    let presentacion = document.querySelector('#presentacion') as HTMLInputElement;
    let tipo = document.querySelector('#tipo') as HTMLInputElement;
    let fabricante = document.querySelector('#fabricante') as HTMLInputElement;
    let condicion = document.querySelector('#condicion') as HTMLInputElement;
    let descripcion = document.querySelector('#descripcion') as HTMLInputElement;

    registro.value = data.registro_sanitario;
    presentacion.value = data.presentacion;
    tipo.value = data.tipo;
    fabricante.value = 'PFIZER';
    if (data.esRecetado) {
      condicion.value = 'Es recetado';
    } else {
      condicion.value = "No es recetado";
    }
    descripcion.value = data.descripcion;
    this.idProducto = data.id;
  }
}
